package com.example.Alertory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlertoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
